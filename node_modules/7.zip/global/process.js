module.exports = require('process');
