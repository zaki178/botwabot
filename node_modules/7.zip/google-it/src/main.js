import googleIt from './googleIt';

module.exports = googleIt;
