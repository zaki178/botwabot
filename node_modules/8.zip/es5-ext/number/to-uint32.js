"use strict";

module.exports = function (value) {
	// eslint-disable-next-line no-bitwise
	return value >>> 0;
};
