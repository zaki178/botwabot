"use strict";

module.exports = require("./is-implemented")() ? Promise.prototype.finally : require("./shim");
