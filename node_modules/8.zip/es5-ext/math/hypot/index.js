"use strict";

module.exports = require("./is-implemented")() ? Math.hypot : require("./shim");
