"use strict";

var isImplemented = require("../../../../array/#/copy-within/is-implemented");

module.exports = function (a) { a(isImplemented(), true); };
