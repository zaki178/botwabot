import {configForm} from "./configForm";
import {imageFoldersPanel} from "./imageFileExplorer";

export var leftPanel = {
	type : "line",
	rows : [
		configForm,
		{ type : "header", template : "Image Folder" },
		imageFoldersPanel
	]
};

