export var quantizedImageClickToCompare = {
	id   : "clickToCompare",
	rows : [
		{
			id     : "imageView1-statistics",
			view   : "template",
			height : 30
		},

		{
			cols : [
				{
					rows : [
						{
							type     : "header",
							template : "Palette"
						},
						{
							id    : "imageView1-palette",
							width : 140,
							view  : "template"
						}
					]
				},
				{
					rows : [
						{
							type     : "header",
							template : "Image"
						},
						{
							id   : "imageView1-image",
							view : "template"
						}
					]
				}
			]
		}

	]

	//view : "template"
};

