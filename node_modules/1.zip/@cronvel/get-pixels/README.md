
Pruned version of get-pixels:
- only node.js
- only local files

See the original package [here](https://npmjs.org/package/get-pixels).



## Credits
(c) 2013-2014 Mikola Lysenko. MIT License
