# Installation
> `npm install --save @types/cacheable-request`

# Summary
This package contains type definitions for cacheable-request (https://github.com/lukechilds/cacheable-request#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/cacheable-request.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 18:05:48 GMT
 * Dependencies: [@types/keyv](https://npmjs.com/package/@types/keyv), [@types/http-cache-semantics](https://npmjs.com/package/@types/http-cache-semantics), [@types/responselike](https://npmjs.com/package/@types/responselike), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [BendingBender](https://github.com/BendingBender), and [Paul Melnikow](https://github.com/paulmelnikow).
