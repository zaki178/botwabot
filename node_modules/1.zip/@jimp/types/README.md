<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/types</h1>
  <p>Default Jimp types.</p>
</div>

## Supported Image Types

- [bmp](../type-bmp)
- [gif](../type-gif)
- [jpeg](../type-jpeg)
- [png](../type-png)
- [tiff](../type-tiff)
