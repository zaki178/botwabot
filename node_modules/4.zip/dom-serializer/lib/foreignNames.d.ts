export declare const elementNames: Map<string, string>;
export declare const attributeNames: Map<string, string>;
//# sourceMappingURL=foreignNames.d.ts.map