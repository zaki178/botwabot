'use strict';

var clc = require('../');

console.log(clc.bold('Bold text'));
console.log(clc.italic('Italic text'));
console.log(clc.underline('Underlined text'));
console.log(clc.blink('Blinking text (might not work for your font)'));
console.log(clc.inverse('Inverse text'));
console.log(clc.strike('Strikethrough text'));
