var boolString  = require('./index.js');

var yesString = "yes";

console.log(boolString(yesString)); // true

var noString = "no";

console.log(boolString(noString)); // false