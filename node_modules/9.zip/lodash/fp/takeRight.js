var convert = require('./convert'),
    func = convert('takeRight', require('../takeRight'));

func.placeholder = require('./placeholder');
module.exports = func;
