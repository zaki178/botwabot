var convert = require('./convert'),
    func = convert('times', require('../times'));

func.placeholder = require('./placeholder');
module.exports = func;
