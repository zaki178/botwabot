export default `flf2a$ 6 5 16 0 14
Original font by Gordon Lee <93cmgl@eng.cam.ac.uk>
==================================================
Original figletization by Tony Nugent (T.Nugent@sct.gu.edu.au)
Version 1  - Needs refining with hardblanks and cleaning up of some of
the characters.  The last 6 chars need to be done properly.
==================================================
Version 2 by Ian Chai <spectre@uiuc.edu> Added the hardblank fix and
the German characters.
==================================================

---

Font modified June 17, 2007 by patorjk 
This was to widen the space character.
$   $@
$   $@
$   $@
$   $@
$   $@
$   $@@
 oo$ @
8888$@
8888$@
 88$ @
 oo$ @
     @@
888 888$@
888 888$@
        @
        @
        @
        @@
 ooo   ooo$ @
o888ooo888o$@
 888   888$ @
o888ooo888o$@
 888   888$ @
            @@
   oo oo$   @
 oo88o88o8$ @
88o88o88oo$ @
   88 88 88$@
o8o88o88o8$ @
   88 88$   @@
 oo     ooo$@
8  8  o88$  @
 88 o88 oo$ @
  o88  8  8$@
o88     88$ @
            @@
 oooooo$    @
888  888$   @
 88o88  o88$@
888  88o8$  @
 888o88 88o$@
            @@
 888$@
 888$@
o88$ @
     @
     @
     @@
  o88$@
 888$ @
888$  @
888$  @
 888$ @
  88o$@@
88o$  @
 888$ @
  888$@
  888$@
 888$ @
o88$  @@
 oo    oo$ @
  88oo88$  @
o88888888o$@
  oo88oo$  @
 o88  88o$ @
           @@
    ooo$    @
    888$    @
oooo888oooo$@
    888$    @
    888$    @
            @@
     @
     @
     @
 ooo$@
 888$@
o88$ @@
          @
          @
ooooooooo$@
          @
          @
          @@
    @
    @
    @
ooo$@
888$@
    @@
        o88$@
       o88$ @
     o88$   @
   o88$     @
 o88$       @
o88$        @@
  ooooooo$  @
o888  o888o$@
888  8  888$@
888o8  o888$@
  88ooo88$  @
            @@
     oo$ @
   o888$ @
    888$ @
    888$ @
   o888o$@
         @@
  ooooooo$  @
o88     888$@
      o888$ @
   o888   o$@
o8888oooo88$@
            @@
  ooooooo$  @
o88    888o$@
    88888o$ @
88o    o888$@
  88ooo88$  @
            @@
      o88$  @
    o8888$  @
  o88 888$  @
o888oo888oo$@
     o888o$ @
            @@
oooooooooo$ @
888$        @
888888888o$ @
ooo    o888$@
  88ooo88$  @
            @@
  ooooooo$  @
o88$        @
888888888o$ @
88o    o888$@
  88ooo88$  @
            @@
ooooooooooo$@
888    888$ @
      888$  @
     888$   @
    888$    @
            @@
  ooooooo$  @
o888   888o$@
 888888888$ @
888o   o888$@
  88ooo88$  @
            @@
 ooooooo$  @
888    88o$@
 888oo8888$@
      888$ @
   o888$   @
           @@
    @
ooo$@
888$@
ooo$@
888$@
    @@
 ooo$@
 888$@
 ooo$@
 888$@
o88$ @
     @@
    o88$@
  o88$  @
o88$    @
  88o$  @
    88o$@
        @@
           @
 ooooooooo$@
           @
 ooooooooo$@
           @
           @@
88o$     @
   88o$  @
     88o$@
   o88$  @
 o88$    @
         @@
o8888888o$  @
888     888$@
     o888$  @
    888$    @
    ooo$    @
            @@
o8888888o$  @
888  oo 888$@
888 8 8 888$@
888  88o88$ @
 888ooooo8$ @
            @@
     o$     @
    888$    @
   8  88$   @
  8oooo88$  @
o88o  o888o$@
            @@
oooooooooo$ @
 888    888$@
 888oooo88$ @
 888    888$@
o888ooo888$ @
            @@
  oooooooo8$@
o888     88$@
888$        @
888o     oo$@
 888oooo88$ @
            @@
ooooooooo$  @
 888    88o$@
 888    888$@
 888    888$@
o888ooo88$  @
            @@
ooooooooooo$@
 888    88$ @
 888ooo8$   @
 888    oo$ @
o888ooo8888$@
            @@
ooooooooooo$@
 888    88$ @
 888ooo8$   @
 888$       @
o888o$      @
            @@
  ooooooo8$ @
o888    88$ @
888    oooo$@
888o    88$ @
 888ooo888$ @
            @@
ooooo ooooo$@
 888   888$ @
 888ooo888$ @
 888   888$ @
o888o o888o$@
            @@
ooooo$@
 888$ @
 888$ @
 888$ @
o888o$@
      @@
  ooooo$@
   888$ @
   888$ @
   888$ @
   888$ @
8o888$  @@
oooo   oooo$@
 888  o88$  @
 888888$    @
 888  88o$  @
o888o o888o$@
            @@
ooooo$      @
 888$       @
 888$       @
 888      o$@
o888ooooo88$@
            @@
oooo     oooo$@
 8888o   888$ @
 88 888o8 88$ @
 88  888  88$ @
o88o  8  o88o$@
              @@
oooo   oooo$@
 8888o  88$ @
 88 888o88$ @
 88   8888$ @
o88o    88$ @
            @@
  ooooooo$  @
o888   888o$@
888     888$@
888o   o888$@
  88ooo88$  @
            @@
oooooooooo$ @
 888    888$@
 888oooo88$ @
 888$       @
o888o$      @
            @@
  ooooooo$  @
o888   888o$@
888     888$@
888o  8o888$@
  88ooo88$  @
       88o8$@@
oooooooooo$ @
 888    888$@
 888oooo88$ @
 888  88o$  @
o888o  88o8$@
            @@
 oooooooo8$ @
888$        @
 888oooooo$ @
        888$@
o88oooo888$ @
            @@
ooooooooooo$@
88  888  88$@
    888$    @
    888$    @
   o888o$   @
            @@
ooooo  oooo$@
 888    88$ @
 888    88$ @
 888    88$ @
  888oo88$  @
            @@
ooooo  oooo$@
 888    88$ @
  888  88$  @
   88888$   @
    888$    @
            @@
oooo     oooo$@
 88   88  88$ @
  88 888 88$  @
   888 888$   @
    8   8$    @
              @@
ooooo  oooo$@
  888  88$  @
    888$    @
   88 888$  @
o88o  o888o$@
            @@
ooooo  oooo$@
  888  88$  @
    888$    @
    888$    @
   o888o$   @
            @@
ooooooooooo$@
88    888$  @
    888$    @
  888    oo$@
o888oooo888$@
            @@
888888$@
888$   @
888$   @
888$   @
888$   @
888888$@@
88o$        @
 88o$       @
   88o$     @
     88o$   @
       88o$ @
        88o$@@
888888$@
   888$@
   888$@
   888$@
   888$@
888888$@@
     o$    @
    o8o$   @
   o888o$  @
  o88o88o$ @
 o8888888o$@
           @@
              @
              @
              @
              @
              @
 oooooooooooo$@@
 888$ @
 888$ @
  88o$@
      @
      @
      @@
            @
  ooooooo$  @
  ooooo888$ @
888    888$ @
 88ooo88 8o$@
            @@
oooo$       @
 888ooooo$  @
 888    888$@
 888    888$@
o888ooo88$  @
            @@
            @
  ooooooo$  @
888     888$@
888$        @
  88ooo888$ @
            @@
       oooo$@
  ooooo888$ @
888    888$ @
888    888$ @
  88ooo888o$@
            @@
            @
 ooooooooo8$@
888oooooo8$ @
888$        @
  88oooo888$@
            @@
  o888o$@
o888oo$ @
 888$   @
 888$   @
o888o$  @
        @@
            @
  oooooooo8$@
888    88o$ @
 888oo888o$ @
888     888$@
 888ooo888$ @@
oooo$       @
 888ooooo$  @
 888   888$ @
 888   888$ @
o888o o888o$@
            @@
 o88$  @
 oooo$ @
  888$ @
  888$ @
 o888o$@
       @@
  o88$@
 oooo$@
  888$@
  888$@
  888$@
 o88$ @@
oooo$       @
 888  ooooo$@
 888o888$   @
 8888 88o$  @
o888o o888o$@
            @@
o888$ @
 888$ @
 888$ @
 888$ @
o888o$@
      @@
              @
oo ooo oooo$  @
 888 888 888$ @
 888 888 888$ @
o888o888o888o$@
              @@
            @
oo oooooo$  @
 888   888$ @
 888   888$ @
o888o o888o$@
            @@
            @
  ooooooo$  @
888     888$@
888     888$@
  88ooo88$  @
            @@
            @
ooooooooo$  @
 888    888$@
 888    888$@
 888ooo88$  @
o888$       @@
            @
  ooooooooo$@
888    888$ @
888    888$ @
  88ooo888$ @
       888o$@@
            @
oo oooooo$  @
 888    888$@
 888$       @
o888o$      @
            @@
            @
 oooooooo8$ @
888ooooooo$ @
        888$@
88oooooo88$ @
            @@
  o8$  @
o888oo$@
 888$  @
 888$  @
  888o$@
       @@
            @
oooo  oooo$ @
 888   888$ @
 888   888$ @
  888o88 8o$@
            @@
            @
oooo   oooo$@
 888   888$ @
  888 888$  @
    888$    @
            @@
              @
oooo  o  oooo$@
 888 888 888$ @
  888888888$  @
   88   88$   @
              @@
            @
oooo   oooo$@
  888o888$  @
  o88 88o$  @
o88o   o88o$@
            @@
            @
oooo   oooo$@
 888   888$ @
  888 888$  @
    8888$   @
 o8o888$    @@
            @
ooooooooooo$@
     8888$  @
  8888$     @
o888ooooooo$@
            @@
  o8888$@
 888$   @
o888$   @
888o$   @
 888$   @
  8888o$@@
888$@
888$@
888$@
888$@
888$@
888$@@
8888o$  @
   888$ @
   888o$@
   o888$@
   888$ @
o8888$  @@
 o888o o888$@
888 888888$ @
            @
            @
            @
            @@
 88  o  88$ @
    888$    @
   8  88$   @
  8oooo88$  @
o88o  o888o$@
            @@
 88ooooo88$ @
o888   888o$@
888     888$@
888o   o888$@
  88ooo88$  @
            @@
o88oo  o88o$@
 888    88$ @
 888    88$ @
 888    88$ @
  888oo88$  @
            @@
 88     88$ @
  ooooooo$  @
  ooooo888$ @
888    888$ @
 88ooo88 8o$@
            @@
 88     88$ @
  ooooooo$  @
888     888$@
888     888$@
  88ooo88$  @
            @@
 88     88  @
oooo  oooo$ @
 888   888$ @
 888   888$ @
  888o88 8o$@
            @@
   ooooooo$ @
 o88    888$@
 888oooo88$ @
 888    888$@
 888 oo888$ @
o88         @@
`