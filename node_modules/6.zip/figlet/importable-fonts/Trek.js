export default `flf2a$ 6 5 16 0 30
//-----------------------------------------------------------//
//                                                           //
//    .dBBBBP dBBBBBBP dBBBBBb   dBBBBBb                     //
//    BP                    BB       dBP                     //
//    \`BBBBb   dBP      dBP BB   dBBBBK                      //
//       dBP  dBP      dBP  BB  dBP  BB                      //
//  dBBBBP'  dBP      dBBBBBBB dBP  dB'                      //
//                                                           //
//                dBBBBBBP dBBBBBb   dBBBP  dBP dBP          //
//                             dBP         dBP.dBP           //
//                dBP     dBBBBK   dBBP   dBBBBP'            //
//               dBP     dBP  BB  dBP    dBP BB              //
//              dBP     dBP  dB' dBBBBP dBP dB'              //
//                                                           //
//                 -=[ The Figlet Font ]=-                   //
//                                                           //
//  [ Version 1.0 ]                                          //
//                                                           //
//  1994, by Peter L. Buschman                               //
//                                                           //
//  Please send all comments to the author at:               //
//                                                           //
//                                                           //
//                        97buschmanp@alma.edu               //
//                        plbuschm@nyx.cs.du.edu             //
//                                                           //
//  OAS AAS LLS!                                             //
//-----------------------------------------------------------//
Height, Up_ht, Maxlength, SmushMode, CommentCount

     $$$@
    $$$ @
   $$$  @
  $$$   @
 $$$    @
$$$     @@
     $dBP@
    $dBP @
   $dBP  @
  $dBP   @
 $       @
$dBP     @@
       @
 $dP dP@
$dP dP @
       @
       @
       @@
$     d88P  @
$ d88888888P@
$d8B88888BP @
$  d88P     @
            @
     _      @@
  $.===.@
  $: |  @
  $\`===.@
  $  | :@
  $\`==='@
  $  "  @@
 $dP  dP@
 $   dP @
 $  dP  @
 $ dP   @
 $dP  dP@
        @@
  .BBb'  @
  B..    @
  >BP    @
 .B      @
..\`BB'   @
         @@
$   @
$dBP@
$BP @
    @
    @
    @@
    $.BBb.@
   $dBP   @
  $dBP    @
 $dBP     @
$dBP      @
$\`BBb     @@
     $dBB.@
    $  dBP@
   $  dBP @
  $  dBP  @
 $  dBP   @
$\`BBB'    @@
$    .. @
$  .::dP@
$  dBBP:@
$  :dBBb@
$  dP::'@
$       @@
   $    @
  $     @
 $  dBP @
$dBBBBBP@
$ dBP   @
        @@
   $ @
  $  @
 $   @
$    @
$$dBP@
$$BP @@
   $$$$$@
  $$$$$$@
 $$$$$$$@
$dBBBBBP@
$$$$$$$$@
        @@
    @
   $@
  $ @
 $  @
$dBP@
    @@
       $__@
     $_dBP@
   $_dBP  @
 $_dBP    @
$dBP      @
          @@
    $dBBBBP@
   $dB'.BP @
  $dB:.BP  @
 $dB'.BP   @
$dBBBBP    @
           @@
 $dBBBb @
        @
  $dBP  @
 $dBP   @
$dBP    @
        @@
 $dBBBBb@
 $      @
  $dBBP @
 $dBP__ @
$dBBBBP @
        @@
  $dBBBBb@
  $      @
  $ dBBBP@
 $   dBP @
$dBBBBP  @
         @@
  $dBP dBP@
 $    dBP @
$dBBBBBP  @
    dBP   @
   dBP    @
          @@
    $dBBBBBP@
   $        @
  $dBBBBBP  @
 $    dBP   @
$dBBBBBP    @
            @@
   $dBBBBP@
  $dP     @
 $dP dBP  @
$dP  dP   @
$VBBBP    @
          @@
$dBBBBb @
        @
  $dBP  @
 $dBP   @
$dBP    @
        @@
    $dBBBb@
   $dP  dP@
  $dPBBBP @
 $dP  dP  @
$ VBBBP   @
          @@
   $dBBBBb@
  $dP  dBP@
  $VBBBBP @
 $    dP  @
$ dBBBP   @
          @@
    $ @
   $  @
  $dBP@
 $    @
$dBP  @
      @@
$     @
$     @
$  dBP@
$     @
$ dBP @
$dBP  @@
     @
$ dP @
$dP  @
$Vb  @
$ Vb @
     @@
        @
  $dBBBP@
 $      @
$dBBBP  @
        @
        @@
     @
$Vb  @
$\`Bb @
$ dP @
$dP  @
     @@
$dBBBBb@
$Vb dBP@
   dBP @
       @
$dBP   @
       @@
   $       @
  $dBBBBBBb@
 $dBP _  dB@
$dBP  " dB'@
$VBBBBBBB' @
           @@
 $dBBBBBb @
   $   BB @
  $dBP BB @
 $dBP  BB @
$dBBBBBBB @
          @@
   $dBBBBb@
   $   dBP@
  $dBBBK' @
 $dB' db  @
$dBBBBP'  @
          @@
    $dBBBP@
   $      @
  $dBP    @
 $dBP     @
$dBBBBP   @
          @@
    $dBBBBb@
   $    dB'@
  $dBP dB' @
 $dBP dB'  @
$dBBBBB'   @
           @@
    $dBBBP @
   $       @
  $dBBP    @
 $dBP      @
$dBBBBP    @
           @@
    $dBBBBP@
   $       @
  $dBBBP   @
 $dBP      @
$dBP       @
           @@
    $dBBBBb@
   $       @
  $dBBBB   @
 $dB' BB   @
$dBBBBBB   @
           @@
    $dBP dBP@
            @
  $dBBBBBP  @
 $dBP dBP   @
$dBP dBP    @
            @@
    $dBP@
   $    @
  $dBP  @
 $dBP   @
$dBP    @
        @@
        dBP@
           @
      dBP  @
 $dB'dBP   @
$dBBBBP    @
           @@
   $ dBP dBP@
    dBP.d8P @
  $dBBBBP'  @
 $dBP BB    @
$dBP dB'    @
            @@
    $dBP@
   $    @
  $dBP  @
 $dBP   @
$dBBBBP @
        @@
     $dBBBBBBb@
    $  '   dB'@
   $dB'dB'dB' @
  $dB'dB'dB'  @
 $dB'dB'dB'   @
              @@
    $dBBBBb@
   $    dBP@
  $dBP dBP @
 $dBP dBP  @
$dBP dBP   @
           @@
    $dBBBBP@
   $dB'.BP @
  $dB'.BP  @
 $dB'.BP   @
$dBBBBP    @
           @@
  $dBBBBBb@
  $    dB'@
  $dBBBP' @
 $dBP     @
$dBP      @
          @@
    $dBBBBP@
   $dB'.BP @
  $dB'.BP  @
 $dB'.BB   @
$dBBBB'B   @
           @@
  $dBBBBBb@
  $    dBP@
  $dBBBBK'@
 $dBP  BB @
$dBP  dB' @
          @@
  .dBBBBP@
  BP     @
  \`BBBBb @
     dBP @
dBBBBP'  @
         @@
$ dBBBBBBP@
          @
  $dBP    @
 $dBP     @
$dBP      @
          @@
    $dBP dBP@
   $        @
  $dBP dBP  @
 $dBP_dBP   @
$dBBBBBP    @
            @@
  dBP dP@
        @
$dB .BP @
 BB.BP  @
 BBBP   @
        @@
    $dBPdBPdBP@
   $          @
  $dBPdBPdBP  @
 $dBPdBPdBP   @
$dBBBBBBBP    @
              @@
$\`Bb  .BP@
 $   .BP @
  $dBBK  @
 $dB'    @
$dB' dBP @
         @@
$dBP dBP@
   $dBP @
  $dBP  @
 $dBP   @
$dBP    @
        @@
$dBBBBBP@
        @
  $dBP  @
 $dBP   @
$dBBBBP @
        @@
     $dBBb $@
    $dBP  $ @
   $dBP  $  @
  $dBP  $   @
 $dBP  $    @
$dBBBP$     @@
       @
\`Bb    @
 \`Bb   @
  \`Bb  @
   \`Bb$@
       @@
     $dBBP$@
    $ dBP$ @
   $ dBP$  @
  $ dBP$   @
 $ dBP$    @
$VBBP$     @@
 $dBb @
$dP\`Bb@
      @
      @
      @
      @@
     $$$@
    $$$$@
   $$$$$@
  $$$$$$@
 $$$$$$$@
$dBBBBBP@@
    @
$dBb@
$\`BP@
$ ' @
    @
    @@
 $dBBBBBb@
       BB@
  $dBP BB@
 $dBP  BB@
$dBBBBBBB@
         @@
   $dBBBBb@
   $   dBP@
  $dBBBK' @
 $dB' db  @
$dBBBBP'  @
          @@
    $dBBBP@
   $      @
  $dBP    @
 $dBP     @
$dBBBBP   @
          @@
    $dBBBBb@
   $    dBP@
  $dBP dBP @
 $dBP dBP  @
$dBBBBBP   @
           @@
    $dBBBP @
   $       @
  $dBBP    @
 $dBP      @
$dBBBBP    @
           @@
    $dBBBBP@
   $       @
  $dBBBP   @
 $dBP      @
$dBP       @
           @@
    $dBBBBb@
   $       @
  $dBBBB   @
 $dB' BB   @
$dBBBBBB   @
           @@
    $dBP dBP@
   $        @
  $dBBBBBP  @
 $dBP dBP   @
$dBP dBP    @
            @@
    $dBP@
   $    @
  $dBP  @
 $dBP   @
$dBP    @
        @@
        dBP@
           @
      dBP  @
 $dB'dBP   @
$dBBBBP    @
           @@
    $dBP dBP@
   $d8P.dBP @
  $dBBBBP   @
 $dBP BB    @
$dBP dBP    @
            @@
    $dBP@
   $    @
  $dBP  @
 $dBP   @
$dBBBBP @
        @@
    $dBBBBBBb@
   $      dBP@
  $dBPdBPdBP @
 $dBPdBPdBP  @
$dBPdBPdBP   @
             @@
    $dBBBBb@
   $    dBP@
  $dBP dBP @
 $dBP dBP  @
$dBP dBP   @
           @@
    $dBBBBP@
   $dBP.BP @
  $dBP.BP  @
 $dBP.BP   @
$dBBBBP    @
           @@
  $dBBBBBb@
  $    dB'@
  $dBBBP' @
 $dBP     @
$dBP      @
          @@
    $dBBBBP@
   $dBP.BP @
  $dBP.BP  @
 $dBP.BB   @
$dBBBB'B   @
           @@
  $dBBBBBb@
  $    dBP@
  $dBBBBK @
 $dBP  BB @
$dBP  dB' @
          @@
  .dBBBBP@
  BP     @
  \`BBBBb @
     dBP @
dBBBBP'  @
         @@
 $dBBBBBBP@
          @
  $dBP    @
 $dBP     @
$dBP      @
          @@
    $dBP dBP@
   $        @
  $dBP dBP  @
 $dBP_dBP   @
$dBBBBBP    @
            @@
   dBP dP@
         @
$dB .BP  @
 BB.BP   @
 BBBP    @
         @@
    $dBPdBPdBP@
   $          @
  $dBPdBPdBP  @
 $dBPdBPdBP   @
$dBBBBBBBP    @
              @@
\`Bb  .BP@
    .BP @
  dBBK  @
 dB'    @
dB' dBP @
        @@
$dBP dBP@
    dBP @
   dBP  @
  dBP   @
 dBP    @
        @@
$dBBBBBP@
        @
  $dBP  @
 $dBP   @
$dBBBBP @
        @@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
`