export default `flf2a$ 5 4 12 -1 36 0 3903 0
Author : Aaron Nolan
Email  : speed_racer420@hotmail.com
Date   : 2005/4/7 10:39:30
Version: 1.0
-------------------------------------------------

-------------------------------------------------
This font has been created using JavE's FIGlet font export assistant.

(english)

(comments): I put in an "�, �, and �" for all you germans out there,
the "�" was a little too difficult. This is of course the FILTER font
inspired from the band logo, have fun. And don't poke an eye out.

(deutsch)

(kommentar): Ich habe auch "�, �, und �" dazu gemacht, f�r Ihr Deutschen
da drausen, das scharfe S (�) war ein bisschen zu schwierig. Dies ist 
natr�rlich
die FILTER schriftart (figlet-font), inspiriert von dem Bandlogo, viel Spa�.
Und, das Auge nicht damit auspfl�cken!

Permission is hereby given to modify this font, as long as the
modifier's, and the original author's name name is placed on a comment line.

Also check out the Malicious (industrial electronic darkwave ebm synthpop) 
band here:

http://themalicious.dmusic.com/
http://themalicious.shim.net/
http://groups.yahoo.com/group/themalicious
http://www.audiostreet.net/themalicious
http://www.roilnoise.com/Industrialterror.htm

thanks.
$ #
$ #
$ #
$ #
$ ##
 d88     #
 d88.    #
 \`'d8    #
      YP #
         ##
 88b 88b #
 \`8p \`8p #
         #
         #
         ##
##
#
#
#
##
$#
 #
 #
 #
 ##
%#
 #
 #
 #
 ##
&#
 #
 #
 #
 ##
'#
 #
 #
 #
 ##
(#
 #
 #
 #
 ##
)#
 #
 #
 #
 ##
*#
 #
 #
 #
 ##
   888    #
ooo888ooo #
888888888 #
   888    #
          ##
,#
 #
 #
 #
 ##
         #
  ______ #
  XXXXXX #
         #
         ##
.#
 #
 #
 #
 ##
/#
 #
 #
 #
 ##
0#
 #
 #
 #
 ##
1#
 #
 #
 #
 ##
2#
 #
 #
 #
 ##
3#
 #
 #
 #
 ##
4#
 #
 #
 #
 ##
5#
 #
 #
 #
 ##
6#
 #
 #
 #
 ##
7#
 #
 #
 #
 ##
8#
 #
 #
 #
 ##
9#
 #
 #
 #
 ##
        #
    d8p #
        #
    d8p #
        ##
        #
    d8p #
        #
    ,d  #
        ##
<#
 #
 #
 #
 ##
         #
  oooooo #
  oooooo #
         #
         ##
>#
 #
 #
 #
 ##
?#
 #
 #
 #
 ##
@#
 #
 #
 #
 ##
,8b.     #
88'8o    #
88PPY8.  #
8b   \`Y' #
         ##
d88PPPo #
888ooo8 #
888   8 #
888PPPP #
        ##
doooooo #
d88     #
d88     #
d888888 #
        ##
  88PPP. #
  88   8 #
  88   8 #
  88oop' #
         ##
  ,d8PPPP #
  d88ooo  #
,88'      #
88bdPPP   #
          ##
  o8boooo #
  88booop #
  88b     #
  88P     #
          ##
888PPP8b #
d88    \` #
d8b PPY8 #
Y8PPPPPP #
         ##
888  888 #
88888888 #
88P  888 #
88P  888 #
         ##
   8888 #
   8888 #
   8888 #
   8888 #
        ##
     d8p #
     88p #
     88P #
  88888' #
         ##
888  ,dP #
888o8P'  #
888 Y8L  #
888  \`8p #
         ##
888      #
888      #
888      #
888PPPPP #
         ##
d88b_o8b #
d88 8'8b #
d88   8b #
Y88   8P #
         ##
888  ,d8 #
888_dPY8 #
8888' 88 #
Y8P   Y8 #
         ##
88888888 #
888  888 #
888  888 #
888oo888 #
         ##
8888PPPp, #
8888    8 #
8888PPPP' #
888P      #
  _  _    ##
88888888  #
88b   Y8  #
888 Yb,8, #
888oopY88 #
          ##
  ,dbPPPp #
  d88ooP' #
,88' P'   #
88  do    #
          ##
88888888  #
88ooooPp  #
       d8 #
8888888P  #
          ##
888888888 #
   '88d   #
  '888    #
'88p      #
          ##
888  888 #
888  888 #
888  888 #
888PP888 #
         ##
d88   88 #
d88   88 #
d88_o8P' #
Y88P'    #
         ##
8d8   d88 #
888,o.d88 #
888P\`Y8b8 #
88P   YP8 #
          ##
88b  d88 #
  88od88 #
  d8PY8d #
Y88  Y8P #
         ##
888   88 #
888ooo88 #
      88 #
PPPPPP8P #
         ##
PPPPP88p' #
    ,dP'  #
  ,dP'    #
YPPPPPPP  #
          ##
[#
 #
 #
 #
 ##
\\#
 #
 #
 #
 ##
]#
 #
 #
 #
 ##
^#
 #
 #
 #
 ##
_#
 #
 #
 #
 ##
\`#
 #
 #
 #
 ##
,8b.     #
88'8o    #
88PPY8.  #
8b   \`Y' #
         ##
d88PPPo #
888ooo8 #
888   8 #
888PPPP #
        ##
doooooo #
d88     #
d88     #
d888888 #
        ##
  88PPP. #
  88   8 #
  88   8 #
  88oop' #
         ##
  ,d8PPPP #
  d88ooo  #
,88'      #
88bdPPP   #
          ##
  o8boooo #
  88booop #
  88b     #
  88P     #
          ##
888PPP8b  #
d88    \`  #
d8b PPY8  #
Y8PPPPPP  #
          ##
888  888 #
88888888 #
88P  888 #
88P  888 #
         ##
   8888 #
   8888 #
   8888 #
   8888 #
        ##
     d8p #
     88p #
     88P #
  88888' #
         ##
888  ,dP #
888o8P'  #
888 Y8L  #
888  \`8p #
         ##
888      #
888      #
888      #
888PPPPP #
         ##
d88b_o8b #
d88 8'8b #
d88   8b #
Y88   8P #
         ##
888  ,d8 #
888_dPY8 #
8888' 88 #
Y8P   Y8 #
         ##
88888888 #
888  888 #
888  888 #
888oo888 #
         ##
8888PPPp, #
8888    8 #
8888PPPP' #
888P      #
  _  _    ##
88888888  #
88b   Y8  #
888 Yb,8, #
888oopY88 #
          ##
  ,dbPPPp #
  d88ooP' #
,88' P'   #
88  do    #
          ##
88888888  #
88ooooPp  #
       d8 #
8888888P  #
          ##
888888888 #
   '88d   #
  '888    #
'88p      #
          ##
888  888 #
888  888 #
888  888 #
888PP888 #
         ##
d88   88 #
d88   88 #
d88_o8P' #
Y88P'    #
         ##
8d8   d88 #
888,o.d88 #
888P\`Y8b8 #
88P   YP8 #
          ##
88b  d88 #
  88od88 #
  d8PY8d #
Y88  Y8P #
         ##
888   88 #
888ooo88 #
      88 #
PPPPPP8P #
          ##
PPPPP88p'#
    ,dP' #
  ,dP'   #
YPPPPPPP #
         ##
{#
 #
 #
 #
 ##
|#
 #
 #
 #
 ##
}#
 #
 #
 #
 ##
~#
 #
 #
 #
 ##
,8b.     #
88'8o    #
88PPY8.  #
8b   \`Y' #
         ##
88888888 #
888  888 #
888  888 #
888oo888 #
         ##
888  888 #
888  888 #
888  888 #
888PP888 #
         ##
    a a  #
   dPPP8 #
   .oood #
   8ppp8 #
         ##
   o  o  #
  poooop #
  88  88 #
  YPPP8P #
         ##
   u  u  #
  d8  d8 #
  d8  d8 #
  YPPP8P #
         ##
�#
 #
 #
 #
 ##`