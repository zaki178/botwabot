export default `flf2a$ 8 6 20 -1 2
Tanja was written for -=Tanja Lynnx Jackson=- by
Christopher J. Pirillo "The Locker Gnome" <pirill44@iscssun.uni.edu>
$$$@
$$$@
$$$@
$$$@
$$$@
$$$@
$$$@
$$$@@
 !)  @
!)11 @
!)11 @
 !)  @
     @
 !)  @
     @
     @@
*** *** @
##  ##  @
##  ##  @
        @
        @
        @
        @
        @@
  #) 33   @
#)3333333 @
  #) 33   @
  #) 33   @
#)3333333 @
  #) 33   @
          @
          @@
   S)    @
 S)4444  @
S) 44    @
 S)4444  @
   S) 44 @
S)44444  @
   S)    @
         @@
 %)   555 @
%)   555  @
    %)5   @
  %)5     @
 %)5   55 @
%)5   55  @
          @
          @@
 &)77    @
&)  77   @
 &)77    @
&)  77   @
&)   77  @
 &)77777 @
         @
         @@
*** @
 ## @
##  @
    @
    @
    @
    @
    @@
   () @
 ()   @
()    @
()    @
 ()   @
   () @
      @
      @@
))    @
  ))  @
   )) @
   )) @
  ))  @
))    @
      @
      @@
    *)    @
*)  8  88 @
  *)8 8   @
*)8888888 @
  *)8 8   @
*)  8  88 @
   *)     @
          @@
       @
       @
  ##   @
###### @
  ##   @
       @
       @
       @@
    @
    @
    @
    @
*** @
 ## @
##  @
    @@
        @
        @
        @
####### @
        @
        @
        @
        @@
   @
   @
   @
   @
** @
## @
   @
   @@
     /)? @
    /)?  @
   /)?   @
  /)?    @
 /)?     @
/)?      @
         @
         @@
 0))))  @
0)  ))) @
0) ) )) @
0) ) )) @
0))  )) @
 0))))  @
        @
        @@
  1)!   @
 1)!!   @
   1)   @
   1)   @
   1)   @
1)!!!!! @
        @
        @@
 2)AAA  @
2)   AA @
    2)  @
   2)   @
  2)    @
2)AAAAA @
        @
        @@
 3)###  @
3)   ## @
   3)#  @
     3) @
3)   ## @
 3)###  @
        @
        @@
4)   SS @
4)   SS @
4)SSSSS @
     4) @
     4) @
     4) @
        @
        @@
5)%%%%  @
5)      @
5)%%%%  @
     5) @
     5) @
5)%%%%  @
        @
        @@
 6)NNN  @
6)      @
6)NNNN  @
6)   NN @
6)   NN @
 6)NNN  @
        @
        @@
7)&&&&& @
    7)  @
   7)   @
  7)    @
 7)     @
7)      @
        @
        @@
 8)***  @
8)   ** @
 8)***  @
8)   ** @
8)   ** @
 8)***  @
        @
        @@
 9)(((  @
9)   (( @
 9)(((( @
     9) @
9)   (( @
 9)(((  @
        @
        @@
   @
   @
## @
   @
## @
   @
   @
   @@
    @
    @
 ## @
    @
*** @
 ## @
##  @
    @@
   <) @
  <)  @
 <)   @
<)    @
 <)   @
  <)  @
   <) @
      @@
        @
        @
####### @
        @
####### @
        @
        @
        @@
>)    @
 >)   @
  >)  @
   >) @
  >)  @
 >)   @
>)    @
      @@
 ?)////  @
?)    // @
    ?)   @
   ?)    @
         @
   ?)    @
         @
         @@
 A)222  @
A)    2 @
A) 2222 @
A) 2  2 @
A)  222 @
 A)     @
        @
        @@
  A)aa   @
 A)  aa  @
A)    aa @
A)aaaaaa @
A)    aa @
A)    aa @
         @
         @@
B)bbbb   @
B)   bb  @
B)bbbb   @
B)   bb  @
B)    bb @
B)bbbbb  @
         @
         @@
  C)ccc  @
 C)   cc @
C)       @
C)       @
 C)   cc @
  C)ccc  @
         @
         @@
D)dddd   @
D)   dd  @
D)    dd @
D)    dd @
D)    dd @
D)ddddd  @
         @
         @@
E)eeeeee @
E)       @
E)eeeee  @
E)       @
E)       @
E)eeeeee @
         @
         @@
F)ffffff @
F)       @
F)fffff  @
F)       @
F)       @
F)       @
         @
         @@
  G)gggg @
 G)      @
G)  ggg  @
G)    gg @
 G)   gg @
  G)ggg  @
         @
         @@
H)    hh @
H)    hh @
H)hhhhhh @
H)    hh @
H)    hh @
H)    hh @
         @
         @@
I)iiii @
  I)   @
  I)   @
  I)   @
  I)   @
I)iiii @
       @
       @@
J)jjjjjj @
    J)   @
    J)   @
J)  jj   @
J)  jj   @
 J)jj    @
         @
         @@
K)   kk  @
K)  kk   @
K)kkk    @
K)  kk   @
K)   kk  @
K)    kk @
         @
         @@
L)       @
L)       @
L)       @
L)       @
L)       @
L)llllll @
         @
         @@
 M)mm mmm  @
M)  mm  mm @
M)  mm  mm @
M)  mm  mm @
M)      mm @
M)      mm @
           @
           @@
N)n   nn @
N)nn  nn @
N) nn nn @
N)  nnnn @
N)   nnn @
N)    nn @
         @
         @@
 O)oooo  @
O)    oo @
O)    oo @
O)    oo @
O)    oo @
 O)oooo  @
         @
         @@
P)ppppp  @
P)    pp @
P)ppppp  @
P)       @
P)       @
P)       @
         @
         @@
 Q)qqqq  @
Q)    qq @
Q)    qq @
Q)  qq q @
Q)   qq  @
 Q)qqq q @
         @
         @@
R)rrrrr  @
R)    rr @
R)  rrr  @
R) rr    @
R)   rr  @
R)    rr @
         @
         @@
 S)ssss  @
S)    ss @
 S)ss    @
     S)  @
S)    ss @
 S)ssss  @
         @
         @@
T)tttttt @
   T)    @
   T)    @
   T)    @
   T)    @
   T)    @
         @
         @@
U)    uu @
U)    uu @
U)    uu @
U)    uu @
U)    uu @
 U)uuuu  @
         @
         @@
V)    vv @
V)    vv @
V)    vv @
 V)  vv  @
  V)vv   @
   V)    @
         @
         @@
W)      ww @
W)      ww @
W)  ww  ww @
W)  ww  ww @
W)  ww  ww @
 W)ww www  @
           @
           @@
X)    xx @
 X)  xx  @
  X)xx   @
  X)xx   @
 X)  xx  @
X)    xx @
         @
         @@
Y)    yy @
 Y)  yy  @
  Y)yy   @
   Y)    @
   Y)    @
   Y)    @
         @
         @@
Z)zzzzzz @
      Z) @
    Z)   @
   Z)    @
 Z)      @
Z)zzzzzz @
         @
         @@
[){{ @
[)   @
[)   @
[)   @
[)   @
[){{ @
     @
     @@
\\)|      @
 \\)|     @
  \\)|    @
   \\)|   @
    \\)|  @
     \\)| @
         @
         @@
])}} @
  ]) @
  ]) @
  ]) @
  ]) @
])}} @
     @
     @@
  **   @
##  ## @
       @
       @
       @
       @
       @
       @@
        @
        @
        @
        @
        @
####### @
        @
        @@
*** @
##  @
 ## @
    @
    @
    @
    @
    @@
        @
        @
a)AAAA  @
 a)AAA  @
a)   A  @
 a)AAAA @
        @
        @@
b)      @
b)      @
b)BBBB  @
b)   BB @
b)   BB @
b)BBBB  @
        @
        @@
        @
        @
 c)CCCC @
c)      @
c)      @
 c)CCCC @
        @
        @@
     d) @
     d) @
 d)DDDD @
d)   DD @
d)   DD @
 d)DDDD @
        @
        @@
        @
        @
e)EEEEE @
e)EEEE  @
e)      @
 e)EEEE @
        @
        @@
 f)FFF @
f)     @
f)FFF  @
f)     @
f)     @
f)     @
       @
       @@
        @
        @
 g)GGG  @
g)   GG @
g)   GG @
 g)GGGG @
     GG @
g)GGGG  @@
h)      @
h)      @
h)HHHH  @
h)   HH @
h)   HH @
h)   HH @
        @
        @@
## @
   @
i) @
i) @
i) @
i) @
   @
   @@
     ## @
        @
     j) @
     j) @
     j) @
     j) @
j)   JJ @
 j)JJJ  @@
k)     @
k)     @
k)  KK @
k)KK   @
k) KK  @
k)  KK @
       @
       @@
l)L  @
 l)  @
 l)  @
 l)  @
 l)  @
l)LL @
     @
     @@
           @
           @
 m)MM MMM  @
m)  MM  MM @
m)  MM  MM @
m)      MM @
           @
           @@
        @
        @
n)NNNN  @
n)   NN @
n)   NN @
n)   NN @
        @
        @@
        @
        @
 o)OOO  @
o)   OO @
o)   OO @
 o)OOO  @
        @
        @@
        @
        @
p)PPPP  @
p)   PP @
p)   PP @
p)PPPP  @
p)      @
p)      @@
        @
        @
 q)QQQ  @
q)   QQ @
q)   QQ @
 q)QQQQ @
     q) @
     q) @@
        @
        @
 r)RRR  @
r)   RR @
r)      @
r)      @
        @
        @@
        @
        @
 s)SSSS @
s)SSSS  @
     s) @
s)SSSS  @
        @
        @@
  t)   @
t)tTTT @
  t)   @
  t)   @
  t)   @
  t)T  @
       @
       @@
        @
        @
u)   UU @
u)   UU @
u)   UU @
 u)UUU  @
        @
        @@
         @
         @
v)    VV @
 v)  VV  @
  v)VV   @
   v)    @
         @
         @@
           @
           @
w)      WW @
w)  WW  WW @
w)  WW  WW @
 w)WW WWW  @
           @
           @@
        @
        @
x)   XX @
  x)X   @
  x)X   @
x)   XX @
        @
        @@
        @
        @
y)   YY @
y)   YY @
y)   YY @
 y)YYYY @
     y) @
y)YYYY  @@
        @
        @
z)ZZZZZ @
    z)  @
  z)    @
z)ZZZZZ @
        @
        @@
 {)[[[ @
  {)   @
[{)    @
  {)   @
 {)    @
 {)[[[ @
       @
       @@
|)\\ @
|)\\ @
|)\\ @
|)\\ @
|)\\ @
|)\\ @
    @
    @@
})]]]  @
  })   @
   })] @
  })   @
   })  @
})]]]  @
       @
       @@
        @
_-\`-_-\` @
        @
        @
        @
        @
        @
        @@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
     \\    /      @
  , . ><>< . ,   @
  \\\\  /..\\  //   @
,  \\\\ \\__/ //  , @
\\\\  \\\\    //  // @
 \\\\  \\\\__//  //  @
  \\\\__\\__/__//   @
    ~~~~~~~~     @@
@
@
@
@
@
@
@
@@
 ####  ####  @
##...##...## @
#T........C# @
 #A......H#  @
  #N....R#   @
   #J..I#    @
    #AS#     @
     ##      @@
`