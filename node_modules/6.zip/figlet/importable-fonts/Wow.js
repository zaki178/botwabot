export default `flf2a$ 1 0 9 -1 13 0 0 0
Author : Pipeline
Date   : 2005/12/2 19:56:55
Version: 1.0
-------------------------------------------------
This font was inspired by pwning nubs in WoW
Use it when you feel a nubblestiltskin is just
begging to be RUINED.
-------------------------------------------------
This font has been created using JavE's FIGlet font export assistant.
Have a look at: http://www.jave.de

Permission is hereby given to modify this font, as long as the
modifier's name is placed on a comment line.
$ ##
!!1 ##
'' ##
###
$##
%##
&##
'##
(##
)##
*##
+ ##
,##
-- ##
.##
/##
0##
1##
2##
3##
4##
5##
6##
7##
8##
9##
:: ##
:; ##
<##
::: ##
>##
?##
@##
//-\\ ##
][3 ##
<< ##
][_) ##
]E ##
][= ##
((6 ##
][-][ ##
]][ ##
;_][ ##
][< ##
][_ ##
][\\/][ ##
][\\][ ##
[[]] ##
]]P ##
[[]]. ##
][2 ##
((5 ##
\`][\` ##
][_][ ##
\\\\/ ##
\\\\/\\\\/ ##
>><< ##
\`\`// ##
\`\`//. ##
[##
\\##
]##
^##
_##
\`##
//-\\ ##
][3 ##
<< ##
][_) ##
]E ##
][= ##
((6 ##
][-][ ##
]][ ##
;_][ ##
][< ##
][_ ##
][\\/][ ##
][\\][ ##
[[]] ##
]]P ##
[[]]. ##
][2 ##
((5 ##
\`][\` ##
][_][ ##
\\\\/ ##
\\\\/\\\\/ ##
>><< ##
\`\`// ##
\`\`//. ##
{##
|##
}##
~##
//-\\ ##
[[]] ##
][_][ ##
//-\\ ##
[[]] ##
][_][ ##
�##
`