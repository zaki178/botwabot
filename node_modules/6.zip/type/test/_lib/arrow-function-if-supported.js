"use strict";

try { module.exports = eval("(() => {})"); }
catch (error) {}
