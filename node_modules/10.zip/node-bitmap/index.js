module.exports = require('./lib/bitmap');
