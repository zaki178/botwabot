npm-start(3) -- Start a package
===============================

## SYNOPSIS

    npm.commands.start(packages, callback)

## DESCRIPTION

This runs a package's "start" script, if one was provided.

npm can start multiple packages. Just specify multiple packages in the
`packages` parameter.
