import { CommonTagMapper } from "../common/GenericTagMapper";
export declare class ID3v1TagMapper extends CommonTagMapper {
    constructor();
}
