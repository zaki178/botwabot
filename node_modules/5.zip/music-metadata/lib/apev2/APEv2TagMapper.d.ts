import { CaseInsensitiveTagMap } from '../common/CaseInsensitiveTagMap';
export declare class APEv2TagMapper extends CaseInsensitiveTagMap {
    constructor();
}
