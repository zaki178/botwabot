import { CaseInsensitiveTagMap } from '../common/CaseInsensitiveTagMap';
export declare const tagType = "iTunes";
export declare class MP4TagMapper extends CaseInsensitiveTagMap {
    constructor();
}
