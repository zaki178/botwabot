import { CaseInsensitiveTagMap } from '../common/CaseInsensitiveTagMap';
export declare class MatroskaTagMapper extends CaseInsensitiveTagMap {
    constructor();
}
