"use strict";

module.exports = require("./lib/weak")(require("./"));
