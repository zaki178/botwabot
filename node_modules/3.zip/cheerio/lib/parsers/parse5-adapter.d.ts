import { Node, Document } from 'domhandler';
import type { InternalOptions } from '../options';
interface Parse5Options extends InternalOptions {
    context?: Node;
}
export declare function parse(content: string, options: Parse5Options, isDocument?: boolean): Document;
export declare function render(dom: Node | ArrayLike<Node>): string;
export {};
//# sourceMappingURL=parse5-adapter.d.ts.map