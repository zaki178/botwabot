module.exports = {
	format: {},
	autodetect: []
}
