export var quantizedImageOriginalVsQuantized = {
	id   : "originalVsQuantized",
	rows : [
		{
			id     : "imageView2-statistics",
			view   : "template",
			height : 30
		},
		{
			cols : [
				{
					rows : [
						{
							type     : "header",
							template : "Palette"
						},
						{
							id    : "imageView2-palette",
							width : 140,
							view  : "template"
						}
					]
				},
				{
					rows : [
						{
							type     : "header",
							template : "Original Image"
						},
						{
							id   : "imageView2-image-original",
							view : "template"
						}
					]
				},
				{
					rows : [
						{
							type     : "header",
							template : "Quantized Image"
						},
						{
							id   : "imageView2-image-quantized",
							view : "template"
						}
					]
				}
			]
		}
	]
};


