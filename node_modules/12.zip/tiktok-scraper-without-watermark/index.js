const { musicallydown, ssstik, keeptiktok, tiktokdownload } = require('./src/function')

exports.musicallydown = musicallydown
exports.ssstik = ssstik
exports.keeptiktok = keeptiktok
exports.tiktokdownload = tiktokdownload
